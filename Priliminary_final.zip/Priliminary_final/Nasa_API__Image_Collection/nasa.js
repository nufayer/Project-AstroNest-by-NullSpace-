document.addEventListener("DOMContentLoaded", () => {
    let searchButton = document.querySelector("#search");
    let searchInput = document.querySelector("#searchTerms");

    // Button click
    searchButton.addEventListener("click", () => {
        console.log("button pressed");
        sendApiRequest();
    });

    // Pressing Enter key inside the input also triggers search
    searchInput.addEventListener("keypress", (event) => {
        if (event.key === "Enter") {
            event.preventDefault();
            console.log("Enter pressed");
            sendApiRequest();
        }
    });
});

async function sendApiRequest() {
    let API_KEY = "oEet1WWu1O1ailNj1zr9HvgdFaa6R7pokc1FU3Uu";

    // Get date from input box
    let date = document.querySelector("#searchTerms").value;

    // Build the API URL
    let url = `https://api.nasa.gov/planetary/apod?api_key=${API_KEY}`;
    if (date) {
        url += `&date=${date}`;
    }

    try {
        let response = await fetch(url);
        let data = await response.json(); // ✅ wait for JSON
        console.log(data);

        if (data.error) {
            document.querySelector("#content").innerHTML = `<p style="color:red;">${data.error.message}</p>`;
        } else {
            useApiData(data);
        }
    } catch (err) {
        document.querySelector("#content").innerHTML = `<p style="color:red;">Error: ${err}</p>`;
    }
}

function useApiData(data) {
    document.querySelector("#content").innerHTML = `
        <h2>${data.title}</h2>
        <p><strong>Date:</strong> ${data.date}</p>
        <p>${data.explanation}</p>
        ${
            data.media_type === "image"
                ? `<img src="${data.url}" alt="${data.title}" width="500"/>`
                : `<iframe width="560" height="315" src="${data.url}" frameborder="0" allowfullscreen></iframe>`
        }
    `;
}
